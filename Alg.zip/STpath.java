
public class STpath { /* data structure to hold s-t paths */
	static final int maxPathLength = 100; 
	int links[] = new int[maxPathLength];
	int numlinks;
	double weight;
	int sampleFlag; // 1 if to be used in optimization, 0 else; randomly chosen
	STpath(){}
}
