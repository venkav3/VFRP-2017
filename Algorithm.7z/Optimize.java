import java.io.IOException;
import java.text.DecimalFormat;

import ilog.concert.*;
import ilog.cplex.IloCplex;
public class Optimize {	
	/* using sparse matrix techniques of filling constraint matrix */
  static DecimalFormat decfor = new DecimalFormat("0.0000");
  static DecimalFormat decfor2 = new DecimalFormat("0.00");
  static int numcols;
  static final double EPS3 = 0.1;
  static final double MARGIN = 0.3;  // to enforce degradation is withing stipulated levels
  static public int MAX = 60000;
  
			
	public static double[] optimize(double alpha, int numNodes, int numArcs, int numSTpaths, Node nodes[], Arc arcs[], STpath stpaths[], int useSTpaths, int useLocations[], double cutValue)throws IloException, IOException
	{
		IloCplex cplex = new IloCplex();
		cplex.setOut(null);

		IloNumVar[][] var = new IloNumVar[1][];
		IloRange[][] rng = new IloRange[1][];
			
		
		// compute # of variables including those required for Martins' MST formulation
		
		numcols = numNodes+numArcs+useSTpaths; 
		System.out.println(" in optimize();, no. of vars = "+numcols+" (numNodes "+numNodes+" numArcs "+numArcs+" useSTpaths "+useSTpaths+" )");
		//System.out.println(" numcol (# of vars. in the problem) "+numcols);
		
		double[] x = new double[numcols];
		double[] y = new double[MAX];
		
		Optimize.ByRow2(numcols, cplex, var, rng, alpha, numNodes, numArcs, numSTpaths, nodes, arcs, stpaths, useSTpaths, useLocations, cutValue);
		long Time1 = System.currentTimeMillis( );
		if (cplex.solve()) {
			System.out.print("cplex.solve completed \n");
			System.out.println(" Solution status = " + cplex.getStatus());
			
			double objVal = cplex.getObjValue();
			
			System.out.println("objval achieved  = " + decfor.format(objVal));
			
			x = cplex.getValues(var[0]);
			for(int i = numNodes+numArcs; i < numcols;++i)
				if(Math.abs(x[i]) < EPS3)
					System.out.println(" path "+i+" slack "+decfor.format(x[i]));
			
			//double[] slack = cplex.getSlacks(rng[0]);
			int nvars = cplex.getNcols();
			int nlinear = cplex.getNrows();
			int nqcs = cplex.getNQCs();
			int ncons = nlinear+nqcs;
			//System.out.println("nvar "+nvars+" nlinear "+nlinear+" nqcs "+nqcs+" ncons "+ncons);
			
			for(int i = 0;i<numNodes;++i)
				y[i] = x[i];
			System.out.println(" nodes attacked: ");;
			for(int i = 0;i< numNodes;++i)
				if(x[i] > EPS3)
					System.out.println(" node "+i);
			
		}
		else
			{System.out.println("cplex didn't solve ");System.out.println("Solution status = " + cplex.getStatus());
			
			System.exit(0);}
		cplex.end();
		long Time2 = System.currentTimeMillis( );
		System.out.println("Time in cplex "+((Time2-Time1)/1000)+" secs. \n");
		return(y);
	}/*end_solveWA()*/
	/*---------------------------------------------------------------------------------------------------------------------------*/
	static void ByRow2(int numvar, IloMPModeler model, IloNumVar[][] var, IloRange[][] rng, double alpha, int numNodes, int numArcs, int numSTpaths, Node nodes[], Arc arcs[], STpath stpaths[], int useSTpaths, int useLocations[], double cutValue) throws IloException {
		
		IloLPMatrix matrix = model.LPMatrix();
		
		//double[] dummy = new double[numvar];
		double[] zlb = new double[numvar];
		double[] zub = new double[numvar];
		IloNumVarType[] zt = new IloNumVarType[numvar];
		double[] objvals = new double[numvar];
		//System.out.println("numvar in ByRow2 "+numvar);
		 
		int xstart = 0;
		int ystart = xstart+numNodes;
		int sstart = ystart+numArcs;
					
		int next = 0;
		
		for(int i=0;i<numNodes;++i)  /* x_u */
		{
		 zlb[i] = 0;
		 zub[i] = 1;
		 zt[i] = IloNumVarType.Bool;
		 objvals[i] = nodes[i].weight;
		 ++next;
		}
		
		for(int i=0;i<numArcs;++i)  /* y_(uv)*/
		{
		 zlb[next] = 0;
		 zub[next] = 1;
		 zt[next] = IloNumVarType.Bool;
		 objvals[next] = 0.00;
		 ++next;
		}
		
		for(int i=0;i<useSTpaths;++i)  /* S_p, for each s-t path p */
		{
		 zlb[next] = 0;
		 zub[next] = Double.MAX_VALUE;
		 zt[next] = IloNumVarType.Float;
		 objvals[next] = 0.00;
		 ++next;
		}
				
	   	if(numvar != next)
			Diagnostic.verror(5,next,numvar);
		
		IloNumVar[] z = model.numVarArray(numvar, zlb, zub, zt);
			
		for(int i=0;i<numvar;++i)
		       matrix.addCols( new IloNumVar[] { z[i] }); 
		var[0] = z;
		model.addMinimize(model.scalProd(z, objvals));
		
		/* add constraints */
		
		IloLinearNumExpr lhs; 
		
		int ncons = 0;
				
		 // constraint (1)
	    for(int i = 0;i<numArcs;++i)  
		  {
	    	int node1 = arcs[i].from;
	    	int node2 = arcs[i].to;
	    	lhs = model.linearNumExpr();
			lhs.addTerm(z[xstart+node1], 1.0);
			lhs.addTerm(z[xstart+node2], 1.0);
			lhs.addTerm(z[ystart+i], 1.0);
	    	matrix.addRow(model.ge(lhs, 1.0-EPS3));
			++ncons;
		   }
		
		// constraint (2) next
		for(int i = 0;i<useSTpaths;++i)  
		  {
			int ind = useLocations[i];  // ind is the position of the path in the stpaths[] array
		    lhs = model.linearNumExpr();
		    for(int j=0;j<stpaths[ind].numlinks;++j)
		    {
		    	int xarc = stpaths[ind].links[j];
		    	lhs.addTerm(z[ystart+xarc], 1.0);
		    }
		   	lhs.addTerm(z[sstart+i], 1.0);
		   	matrix.addRow(model.eq(lhs, stpaths[ind].numlinks));
			++ncons;
		 }
				
		// constraint (3) next
		for(int i = 0;i<useSTpaths;++i)  
		  {
			int ind = useLocations[i];  // ind is the position of the path in the stpaths[] array
		    lhs = model.linearNumExpr();
		    for(int j=0;j<stpaths[ind].numlinks;++j)
		    {
		    	int xarc = stpaths[ind].links[j];
		    	lhs.addTerm(z[ystart+xarc], -Math.log(arcs[xarc].prob));
		    }
		   	lhs.addTerm(z[sstart+i], -Math.log(1-alpha));
		   	matrix.addRow(model.ge(lhs, -Math.log(1-alpha)));
			++ncons;
		 }
		
		// add a cut giving a lower bnd. on the obj. value
		lhs = model.linearNumExpr();
		for(int i=0;i<numNodes;++i)
			lhs.addTerm(z[xstart+i], nodes[i].weight);
		matrix.addRow(model.ge(lhs, cutValue));
		++ncons;
		
	System.out.println(" no. of constraints in the problem "+ncons );
	model.add(matrix);	
	
	IloRange rng2[] =  matrix.getRanges();
	rng[0] = rng2;
	
	System.out.println("model set up for cplex");
	}/*end_ByRows2()*/
	/*-------------------------------------------------------------------------------------------------------*/
	

}
