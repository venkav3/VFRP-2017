// Solves the interdiction problem on a SINGLE NETWOK with probabilities on links.  Aggregates all the nodes in S into node 0, aggregates all nodes in T to node1
// Any s-t link in the resulting network is broken to disallow a trivial solution (node 0 or 1 targeted and disabled).
// Nodes have random weights.  Weights of node 0, node 1 are set to 100 (Big M) to disallow nodes 0, 1 being targeted (trivial solution).
// finds min weight nodes to target so that in the resulting network all s-t paths, i.e., 0-1 paths, have probability no more than (1-alpha) (say 0.01).
//import ilog.concert.IloException;
// full optimization
// 
//same as Cas17a except that only random paths 10% are sampled and sent to the MIP Master Program.
//
//this sampling is performed in samplePaths() and the sampleFlag is set to 1 in stpaths[] array; also printed out to a file for record
 
import ilog.concert.IloException;
/*
import model.Arc;
import model.Demand;
import model.Generator;
import model.Node;
import model.OutPut;
import model.Transit;
*/
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.*;




public class Alg {
	
	static double alpha;
	static public int BigM = 100;
	static DecimalFormat decfor = new DecimalFormat("0.000");
	static final double EPS1 = 0.0001;
	static public double lastShortest;
	static public int maxArcs = 5000;
	static public int maxNodes = 1000;
	static final int maxDegree = 30;
	static public int MAXITER = 100;
	static public int YenK = 5000;
	static public int maxPaths = MAXITER*YenK;
	static public int maxPathlength = 100;
	static public double maxWeight = -0.1;  // initialize with invalid value
	static public double samplingProp = 0.01;   // try 1%
	static public int numUsePaths = 20000; // maximum no. of sampled paths to be used in the master MIP
	
		
	static public int iter;	
	static public int numArcs0;  /* suffix 0 refers to original network parameters before transformation of S to s and T to t */
	static public int numNodes0;
	static public int numArcs;
	static public int numNodes;
	static public int numSset;
	static public int numTset;
	static public int numSTpaths; // total no. of paths in stpaths[] array
	static public int useSTpaths; // no. of paths in the andom sample 
	
	
	static Arc arcs0[] = new Arc[maxArcs];
	static Node nodes0[] = new Node[maxNodes];
	static Arc arcs[] = new Arc[maxArcs];
	static Node nodes[] = new Node[maxNodes];
	static STpath stpaths[] = new STpath[maxPaths*maxPathlength];
	static public int useLocations[] = new int[numUsePaths];
	
	//-----------------------------------------------------------------------------------------------
	public int checkDupArc(int inew, int node1, int node2, Arc arcs[])
	{
		// when setting up the transformed network checks if this arc has been seen before; location in arcs[] sent back, else -1
		for(int i = 0; i<inew;++i)
		{
			int node3, node4;
			node3 = arcs[i].from;
			node4 = arcs[i].to;
			if((node3 == node1) && (node4 == node2))
				return(i);
			if((node3 == node2) && (node4 == node1))
				return(i);
		}
		return(-1);
				
	}/*end_checkDupArc()*/
	/*----------------------------------------------------------------------------------------------*/
	
	   public int findArc(int node1, int node2){
		
		for(int i=0;i<nodes[node1].degAll;++i)
		{
			int ilink = nodes[node1].incidentArcs[i];
			if(otherNode(node1,ilink) == node2)
				return(ilink);
		}
		return(-1); // error condition
	}/*end_findArc()*/
	//------------------------------------------------------------------------------------------------
   public void genKpaths(String vfile) throws NumberFormatException,
	IOException {
	Graph vgraph = new VariableGraph(vfile);
	
	long Time1 = System.currentTimeMillis( );
	YenTopKShortestPathsAlg yenAlg = new YenTopKShortestPathsAlg(vgraph);
	List<Path> shortest_paths_list = yenAlg.getShortestPaths(
           vgraph.getVertex(0), vgraph.getVertex(1), YenK);
	long Time2 = System.currentTimeMillis( );
	System.out.println(" Time in yenAlg for "+YenK+" shortest paths "+((Time2-Time1)/1000)+" secs. \n");
	//System.out.println(":"+shortest_paths_list);
	//System.out.println(yenAlg.getResultList().size());
	Path  p;
	List<BaseVertex> vList;
	double vweight;
	double first=0, last=0;
	int vsize;
	
	int num2 = yenAlg.getResultList().size();
	int num = numSTpaths;
	for(int i = 0; i< num2; ++i)
	{
		stpaths[num] = new STpath();
		p = shortest_paths_list.get(i);
		vList = p.getVertexList();
		vweight = p.getWeight();
		if(i == 0)
			first = vweight;
		if(i == num2-1)
			last = vweight;
		if(vweight > -Math.log(1-alpha))  // work with only high probability paths; ignore the others
			continue;
		if(maxWeight < vweight)
			maxWeight = vweight;
		vsize = vList.size();
		int pathLength = vsize-1;
		stpaths[num].numlinks = pathLength;
		stpaths[num].weight = vweight;
		if(pathLength > maxPathlength)
			Diagnostic.verror(9,pathLength,STpath.maxPathLength);
		//System.out.println("\n path ");
		
		for(int j=0;j < vsize;++j)
		{
			if(j < vsize -1)
			{
			   int node1 = vList.get(j).getId();
			   int node2 = vList.get(j+1).getId();
			   //System.out.println("( "+node1+" , "+node2+")");
			   int ilink = findArc(node1,node2);
			   if(ilink == -1){
				   System.out.println("\n *** could not find arc for "+node1+" to "+node2+ " aborting ***");
				   System.exit(0);
			   }
			   stpaths[num].links[j] = ilink;
			}
			//System.out.print(vList.get(j)+" ");
		}
		++num;
		/********
			System.out.println(" weight "+vweight);
			System.out.println("\n "+ vList.size()+" weight "+vweight);
		    System.out.println("\n  "+shortest_paths_list.get(i));
	     * *******/
	}
	numSTpaths =num;
	System.out.println(" in Yen alg  first "+decfor.format(first)+" last "+decfor.format(last));
	}/* end_genKpaths()*/
	//----------------------------------------------------------------------------------------------------------------------
   public void killDirectConnection()
	{
		// if there is a direct s-t connection in the random network generated, break connection by assigning a very low probability to the arc
		
		for(int i = 0; i< nodes[0].degAll;++i)
			if(nodes[0].nBors[i] == 1)
			{
				int xarc = findArc(0,1);
				arcs[xarc].flag = 0;
				System.out.println("\n *** s-t direct link detected in input graph; breaking connection by disallowing arc *** \n");
				break;
			}
	}//end_killDirectConnection()
	//-------------------------------------------------------------------------------------------------
   public void load(int inode, int ilink, Node nodes[], Arc arcs[])
	{
		/* load ilink into data-structure of incident links on inode	 */
		int ind = nodes[inode].degAll;
		if(ind >= maxDegree)
			Diagnostic.verror(3, inode, maxDegree);
		// determine neighbor from ilink appropriately
		int nbor = arcs[ilink].from;
		if(nbor == inode)
			nbor = arcs[ilink].to;
		// check if this is a repeat link
		for(int i = 0; i<ind;++i)
			if(nodes[inode].nBors[i]==nbor)
				Diagnostic.verror(4, inode, nbor);
		nodes[inode].nBors[ind] = nbor;
		nodes[inode].incidentArcs[ind] = ilink;
		++nodes[inode].degAll;
		if(arcs[ilink].type == 0)
			++nodes[inode].degIntra;
	}/*end_load()*/
/*----------------------------------------------------------------------------------------------*/
		public static void main(String[] args) throws IloException, IOException  {
			
			double cutValue = 26;
		
	    	Alg driver = new Alg();

			long startTimeMs = System.currentTimeMillis( );
			
			alpha= Double.parseDouble(args[0]);
						
			System.out.println("\n Confidence level alpha (e.g. 0.99): "+ args[0]);
			try {
				
				driver.read_input(args[1],args[2]);
				
				//Diagnostic.dumpNodes(numNodes0,numArcs0,nodes0,arcs0);
				} catch (NumberFormatException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				}
			
			String vfile = "//cob-file.scheller.gatech.edu/profiles/profiles/vvenkate3/Documents/Desktop/Computational_Tests/VFRP17/temFile.txt";
			numSTpaths = 0;
			
			
			//Diagnostic.dumpSTpaths(numSTpaths, stpaths, arcs);
						
			double[] soln = new double[numNodes+numArcs+MAXITER*YenK];
			
			int flag=0;
			useSTpaths = 0;
			

			for(iter = 0;iter < MAXITER;++iter)
			{
				if(iter == 0)
				{   // default handling of network only for iter 0
					transcribe(vfile);
					driver.genKpaths(vfile);
				}
				samplePaths();
				//System.out.println(" numSTpaths "+numSTpaths+" prior to call to CPLEX"); Diagnostic.dumpSTpaths(numSTpaths, stpaths, arcs);
				System.out.println("*** Iter ***"+iter);
				soln = Optimize.optimize(alpha, numNodes, numArcs, numSTpaths, nodes, arcs, stpaths, useSTpaths, useLocations, cutValue);
				// update cutvalue
				cutValue = 0.0;
				for(int i = 0;i<numNodes;++i)
					cutValue += soln[i]*nodes[i].weight;
				/***********
				if(Diagnostic.checkPathsKilled(numNodes, numSTpaths, stpaths, arcs, soln)==1)
					System.out.println(" all paths in stpaths[] successfully blocked by soln[] nodes");
				else
					System.out.println(" **** Warning! All paths in stpaths[] NOT blocked by soln[] nodes ****");
					
				Diagnostic.printSoln(soln, numNodes,nodes);
				*****************/
				
				flag = Alg.testSoln(soln, vfile); //testSoln first simulates attack on targeted node, verifies shortest path in network, resets network to original status
				if(flag == 1)
				{   Diagnostic.printSoln(soln, numNodes,nodes);
					break;
				}
				else
				{   
					updateNetwork2(soln); //  update2() must carefully kill all existing paths in stpaths[] so as to get the next yenK shortest paths
					// but it cannot kill all links in each path; kill only those links also incident on attacked nodes. reset2() will restore network to original status after call to yes alg.
					transcribe(vfile);
					driver.genKpaths(vfile);  // paths in the stpaths[] array can be progressive (i.e. predicated on current nodes killed as per CPLEX); these paths
					// are a subset of set of s-t paths in the original network.  CPLEX is solving a relaxed problem with only a subset of s-t paths 
					resetNetwork();  // reset network to original form; undo update2() 
				 }
			}
			if(flag == 1)
				System.out.println("Solution optimal; all path probabilities less than "+decfor.format((1-alpha)));
			if(flag == 0)
				System.out.println(" iter "+iter+" = MAXITER "+MAXITER+" some path probabilities greater than "+decfor.format((1-alpha)));
			
			
			System.out.println("\n *** DONE ***");
			long finisTime =  System.currentTimeMillis( );
			long elapseTime = finisTime-startTimeMs;
			System.out.println(" elapse time (Ms) "+elapseTime);
			transcribePaths(args[3]);
		
	}/* end_main() */
/*----------------------------------------------------------------------------------------------------------------------*/
		public int otherNode(int node1, int xarc){
			
			if(arcs[xarc].from != node1)
				return(arcs[xarc].from);
			else
				return(arcs[xarc].to);
		}/*end_otherNode()*/
//------------------------------------------------------------------------------------------------
        public void read_input(String path1, String path2) throws NumberFormatException,
			IOException {
		DataInputStream istream = new DataInputStream(new FileInputStream(path1));
		BufferedReader buffer = new BufferedReader(new InputStreamReader(
				istream));
		String str;
        System.out.println("file "+path1);
		// String field[];
		str = buffer.readLine(); /* first line in Bienstock data */
		String field[] = str.split("\t");
		numNodes0 = Integer.parseInt(field[0]);
		numArcs0 = Integer.parseInt(field[1]);
		numSset = Integer.parseInt(field[2]);
		numTset = Integer.parseInt(field[3]);
		
		
		if (numNodes0 > maxNodes)
			Diagnostic.verror(1, numNodes0, maxNodes);
		if (numArcs0 > maxArcs)
			Diagnostic.verror(2, numArcs0, maxArcs);
		
		for (int i = 0; i < numNodes0; ++i)
		{
			nodes0[i] = new Node();
			nodes0[i].type = 0; // set to default value
			nodes0[i].network = 1; // dummy value
			nodes0[i].origNum = i;
		}
						
		//-----------------------------------------------------------------------------------
		str = buffer.readLine(); /* do a dummy read */
		for (int i = 0; i < numSset; ++i) /* read S set members; one to a line in input file */
			{
				str = buffer.readLine(); 
				field = str.split("\t");
				int inode = Integer.parseInt(field[0]);
				nodes0[inode].type = 1;
				nodes0[inode].newNum = 0; // perform aggregation - assign S to node 0, T to 1
			}
		//------------------------------------------------------------------------------------
		str = buffer.readLine(); /* do a dummy read */
		for (int i = 0; i < numTset; ++i) /* read T set members */
		{
			str = buffer.readLine(); 
			field = str.split("\t");
			int inode = Integer.parseInt(field[0]);
			nodes0[inode].type = 2;
			nodes0[inode].newNum = 1; // perform aggregation - assign S to node 0, T to 1
		}
		//------------------------------------------------------------------------------------
		// assign new numbers to other nodes next
		int inew = 2;
		for(int i = 0;i < numNodes0;++i)
		{
			if(nodes0[i].type == 0)
			{
				nodes0[i].newNum = inew;
				++inew;
			}
		}
		numNodes = numNodes0-numSset-numTset+2;  // no. of nodes in effective network
		if(inew != numNodes)
			Diagnostic.verror(8, inew, numNodes);
		for (int i = 0; i < numNodes; ++i)
		{
			nodes[i] = new Node();
			nodes[i].type = 0; // default value
			nodes[i].network = 1; // dummy value
		}
		nodes[0].type = 1; // code for s
		nodes[1].type = 2; // code for t
		for(int i=0;i<numNodes0;++i)
		{
			inew = nodes0[i].newNum;
			nodes[inew].origNum = i;
		}
		
		for (int i = 0; i < numArcs0; ++i)
			arcs0[i] = new Arc();
		
		for (int i = 0; i < numArcs0; ++i) /* read arc info */
		{
			str = buffer.readLine();

			int node1, node2;
			field = str.split("\t");
			//System.out.println("filed 0 "+field[0]+" field 1"+field[1]);
			arcs0[i].from = node1 = Integer.parseInt(field[0]);
			arcs0[i].to = node2 = Integer.parseInt(field[1]);
			arcs0[i].prob =  Double.parseDouble(field[2]);
		}
		
		str = buffer.readLine(); /* do final dummy read */
		buffer.close();
		
		istream = new DataInputStream(new FileInputStream(path2));  // read node weights next
	    buffer = new BufferedReader(new InputStreamReader(istream));
			    
        for(int i=0;i<numNodes0;++i)
        {
		  str = buffer.readLine(); 
		  field = str.split("\t");
		  nodes0[i].weight = Double.parseDouble(field[0]);
		  int node1 = nodes0[i].newNum;
		  nodes[node1].weight = nodes0[i].weight;  // populate node weights in transformed network
        }	
        
        //for(int i=0;i<numNodes;++i)
        	//System.out.println(" node "+i+" weight "+nodes[i].weight);
		
		
		//construct arcs data-structure for transformed network
		inew = 0;
		for (int i = 0; i < numArcs0; ++i) 
		{
			int node1, node2, node3, node4;
			node1 = arcs0[i].from;
			node2 = arcs0[i].to;
			node3 = nodes0[node1].newNum;
			node4 = nodes0[node2].newNum;
			if(node3 == node4)
				continue;
			//System.out.println(" node3 "+node3+" node4 "+node4+" node1 "+node1+" node2 "+node2);
			// check if this maps into an already known link in the transformed network, i.e. in the arcs[] array
			int xflag = checkDupArc(inew, node3, node4, arcs);
			if(xflag >= 0)
			{
				//duplicate, adjust probability accordingly
				double xp = arcs[xflag].prob;
				arcs[xflag].prob = xp+arcs0[i].prob - xp*arcs0[i].prob;
			}
			else
			{
			  // new arc in the transformed network
				arcs[inew] = new Arc();
				arcs[inew].from = node3;
				arcs[inew].to = node4;
				arcs[inew].prob = arcs0[i].prob;
				arcs[inew].flag = 1; // start by including all arcs in the problem
				arcs[inew].type = 0; // immaterial for a single network; only matters when we have multiple interconnected networks
				load(node3,inew,nodes,arcs);
				load(node4,inew,nodes,arcs);
				++inew;
			}
		}
		numArcs = inew;
		killDirectConnection(); // if s-t link exists in resulting graph break to disallow trivial solution
		
		// set weights of nodes 0 1 to BigM
		nodes[0].weight = BigM;
		nodes[1].weight = BigM;
		
		
		System.out.println("numNodes "+numNodes+" numArcs "+numArcs);
		//System.exit(0);
		//Diagnostic.dumpNodes(numNodes, numArcs, nodes, arcs);
		//Diagnostic.dumpArcs(numArcs,  arcs);
		
		// verify if each input network is connected
		
		int[] tempA = new int[maxNodes];
		Node[] nodes2 = new Node[maxNodes];
		int ncomp;
		
		for(int i=0;i<numNodes;++i)
			tempA[i] = i;
		nodes2 = Component.loadCompTesting(numNodes,tempA,nodes);
		if((ncomp = Component.find_components(numNodes, nodes2)) != 1)
		{
			System.out.println(" network not connected; no. of components =  "+ncomp);
			System.exit(0);
		}
		
		System.out.println("input network tested and found to be connected (if all links functional) \n");
		
		
	} /* end_read_input() */
/*----------------------------------------------------------------------------------------------*/
public static void resetNetwork() throws IOException 
{
	
	for(int i=0;i<numArcs;++i)
		arcs[i].flag = 1; // reset all arcs to original "include in path calculation" status
}//resetNetwork()
//------------------------------------------------------------------------------------------------------------------------
public static void samplePaths()
{
	Random r = new Random();
	// first reset sampleFlag in stpaths array to all 0's
	
	/***************************** do not reset, use cumulative approach **************************
	for(int i=0;i<numSTpaths;++i)
		stpaths[i].sampleFlag = 0;
	*************************************************************/
	int lo = iter*YenK;
	int hi = (iter+1)*YenK;
	for(int i = lo; i < hi;++i)
	{	
		if(useSTpaths == numUsePaths)
			Diagnostic.verror(10,useSTpaths,numUsePaths);
		double x = r.nextDouble(); 
		if(x < samplingProp)
		{
			stpaths[i].sampleFlag = 1;
			useLocations[useSTpaths] = i;
			++useSTpaths;
		}
	}
	
}/*end_samplePaths()*/
//------------------------------------------------------------------------------------------------------------------------------
public static int testSoln(double soln[], String vfile) throws IOException 
    {
		updateNetwork(soln);
		
		transcribe(vfile);
		
		Graph vgraph = new VariableGraph(vfile);
		
		YenTopKShortestPathsAlg yenAlg = new YenTopKShortestPathsAlg(vgraph);
		List<Path> shortest_paths_list = yenAlg.getShortestPaths(
	            vgraph.getVertex(0), vgraph.getVertex(1), 1); // find the shortest path in new network
		resetNetwork();
		int inum = yenAlg.getResultList().size();
		if(inum == 0)
		{
			System.out.println(" no s-t paths found");
			return(1);
		}
		Path  p;
		List<BaseVertex> vList;
		p = shortest_paths_list.get(0);
		double xShortest = p.getWeight();
		
		/*
		if(lastShortest > xShortest)
		{
			System.out.println(" lastShortest "+decfor.format(lastShortest)+" > xshortest "+decfor.format(xShortest)+" aborting ***");
			System.out.println("Dump of STpaths: \n");
			Diagnostic.dumpSTpaths(numSTpaths,stpaths,arcs);
			System.exit(0);
		}
		*/
		
		lastShortest = xShortest;
		vList = p.getVertexList();
		int vsize = vList.size();
		System.out.println("\n shortest path ");
		for(int j=0;j < vsize;++j)
			System.out.print(vList.get(j)+" ");
		System.out.println(" shortest path metric "+decfor.format(lastShortest)+ " threshold "+decfor.format((-Math.log(1-alpha))));
		System.out.println(" in Yen Alg, last shortest path "+decfor.format(maxWeight)+" but after cplex call shortest "+decfor.format(xShortest));
		//if(xShortest < maxWeight)
			//System.exit(0);
		if(p.getWeight() > -Math.log(1-alpha))
			return(1);
		else
			return(0);
		
    }/*end_testSoln()*/
//---------------------------------------------------------------------------------------------------------------------------
	public static void transcribe(String vfile) throws IOException
    {
		String towrite;
    	OutPut.initFile(vfile);
        //towrite = "\n";
        //OutPut.writeOut(vfile, towrite);
        towrite = numNodes+"\r\n";
        OutPut.writeOut(vfile, towrite);
        for(int i=0;i<numArcs;++i)
        {
        	if(arcs[i].flag == 0)
        		continue; // do not transcribe arc if deemed to be excluded
        	int node1 = arcs[i].from;
        	int node2 = arcs[i].to;
        	double x = -Math.log(arcs[i].prob);
        	towrite = node1+" "+node2+" "+x+"\r\n";
        	OutPut.writeOut(vfile, towrite);
        	towrite = node2+" "+node1+" "+x+"\r\n";  // yen's method on directed graphs; so replace each edge in original graph with two directed edges
        	OutPut.writeOut(vfile, towrite);
        }
        	
    }//end_transcribe()
//---------------------------------------------------------------------------------------------------------------------- 
	public static void transcribePaths(String vfile) throws IOException
    {
		String towrite;
    	OutPut.initFile(vfile);
        //towrite = "\n";
        //OutPut.writeOut(vfile, towrite);
        //towrite = numNodes+"\r\n";
        //OutPut.writeOut(vfile, towrite);
        int inum = 0;
        for(int i=0;i<numSTpaths;++i)
        	if(stpaths[i].sampleFlag ==1) // so in the sample used in the optimization
        	{
        		towrite = "\r\n path "+inum+": ";
        		OutPut.writeOut(vfile, towrite);
		   		 int numlinks = stpaths[i].numlinks;
		   		 int last = 0;
		   		 towrite = Integer.toString(last);
		   		 OutPut.writeOut(vfile, towrite);
		   		 
		   		 for(int j=0;j<numlinks;++j)
		   		 {
		   			int ilink = stpaths[i].links[j];
		   			int node1 = arcs[ilink].from;
		   			int node2 = arcs[ilink].to;
		   			if( node1 == last)
		   				{towrite = " "+node2; OutPut.writeOut(vfile, towrite); last = node2;}
		   			else
		   				{towrite = " "+node1; OutPut.writeOut(vfile, towrite); last = node1;}
		   		 }
		   		 //System.out.println("weight "+decfor.format(stpaths[i].weight));
		   		 
		   		++inum;
        	}
        	
    }//end_transcribePaths()
//---------------------------------------------------------------------------------------------------------------------- 
    public static void updateNetwork(double soln[]) throws IOException 
    {
		for(int i = 0;i<numNodes;++i)
			if(soln[i] > 0.00) // attacked node, disabled incident links
			{
				//System.out.println(" check in update() - node attacked: "+i);									
				for(int j=0;j< nodes[i].degAll;++j)
				{
					int xarc = nodes[i].incidentArcs[j];
					arcs[xarc].flag = 0; // disable arc
			    }
			}		
    }//updateNetwork()
//------------------------------------------------------------------------------------------------------------------------
    public static void updateNetwork2(double soln[]) throws IOException 
    {
    	int dummy[] = new int[100]; // list of attacked nodes
    	int jnum = 0; //counts no. of attacked nodes
    	
    	for(int i=0;i<numNodes;++i)
    		if(soln[i] > 0.00)
    		{
    			dummy[jnum] = i;
		    	++jnum;
		    }
		
		for(int i=0;i< numSTpaths;++i)
		{
			for(int j=0;j<stpaths[i].numlinks;++j)
			{
			  int xarc = stpaths[i].links[j];
			  if(Diagnostic.checkKilled(arcs[xarc].from,jnum,dummy) == 1) 
				arcs[xarc].flag = 0; // disable arc; one end is an attacked node 
			  if(Diagnostic.checkKilled(arcs[xarc].to,jnum,dummy) == 1) 
					arcs[xarc].flag = 0; // disable arc; one end is an attacked node 
			}
		}
    }//updateNetwork2()
//------------------------------------------------------------------------------------------------------------------------
}/* end_class */

